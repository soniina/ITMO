public interface C {

    int[] ii();

    double ad();
}

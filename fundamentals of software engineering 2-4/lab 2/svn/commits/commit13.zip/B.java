public interface B {

    java.util.Set<Integer> ll();

    int ae();
}

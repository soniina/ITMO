public class C extends null {

    int[] ii();

    double ad();
}
